package com.iiit.adb.emp.dblayer.syscatalogue;

public class Horizontal {
	int tblId;
	int fragNo;
	int siteId;
	String fragCondition;
	
	
	public int getTblId() {
		return tblId;
	}
	public void setTblId(int tbl_id) {
		this.tblId = tbl_id;
	}
	public int getFragNo() {
		return fragNo;
	}
	public void setFragNo(int fragNo) {
		this.fragNo = fragNo;
	}
	public int getSiteId() {
		return siteId;
	}
	public void setSiteId(int string) {
		this.siteId = string;
	}
	public String getFragCondition() {
		return fragCondition;
	}
	public void setFragCondition(String fragCondition) {
		this.fragCondition = fragCondition;
	}
	

}
