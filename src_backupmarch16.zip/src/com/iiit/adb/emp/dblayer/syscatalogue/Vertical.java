package com.iiit.adb.emp.dblayer.syscatalogue;

public class Vertical {

	int tblId;
	int fragNo;
	int siteId;
	String colNames;
	
	
	public int getTblId() {
		return tblId;
	}
	public void setTblId(int tblId) {
		this.tblId = tblId;
	}
	public int getFragNo() {
		return fragNo;
	}
	public void setFragNo(int fragNo) {
		this.fragNo = fragNo;
	}
	public int getSiteId() {
		return siteId;
	}
	public void setSiteId(int siteId) {
		this.siteId = siteId;
	}
	public String getColNames() {
		return colNames;
	}
	public void setColNames(String colNames) {
		this.colNames = colNames;
	}
}
