package com.iiit.adb.emp.dblayer.syscatalogue;

public class NoFrag {

	int tblId;
	int siteId;
	
	public int getTblId() {
		return tblId;
	}
	public void setTblId(int tblId) {
		this.tblId = tblId;
	}
	public int getSiteId() {
		return siteId;
	}
	public void setSiteId(int siteid) {
		this.siteId = siteid;
	}
	
}
