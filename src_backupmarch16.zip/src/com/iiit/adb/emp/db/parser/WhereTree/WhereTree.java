package com.iiit.adb.emp.db.parser.WhereTree;

import java.util.ArrayList;
import java.util.Iterator;

import com.iiit.adb.emp.dblayer.syscatalogue.Tbl;

public class WhereTree {
	private WhereNode root = null;
	ArrayList<Tbl> tbl = null;
	String cstr = new String();
	public WhereTree(){
	}
	public WhereNode getRoot(){
		return root;
	}
	public void setRoot(WhereNode r){
		root = r;
	}
	public void displayTree(){
		if (root == null) return;
		display(root);
	}
	private void display(WhereNode node){
		if(node.IsLeaf()){
			node.display();
		}
		else{
			display(node.getLeftChild());
			node.display();
			display(node.getRightChild());
		}
	}
	
	public void validateWhere(ArrayList<Tbl> tbl, String cstr) throws Exception{
		// This is where the checking into the db layer should be done
		this.tbl = tbl;
		this.cstr = cstr;
		if (root == null) return;
		validate(root);
		
		
	}
	
	private void validate(WhereNode node) throws Exception{
		if ((node instanceof ValueNode) || (node instanceof AttrNode)){
			return;
		}
		if((node instanceof AndNode) || (node instanceof OrNode))
		{
			validate(node.getLeftChild());
			//node.display();
			validate(node.getRightChild());
			return;
		}
		// what should we do here. may be we should do it on "=", <=,>=,<,>
		if (node instanceof OpNode){
			OpNode onode = (OpNode)node;
			String op = onode.getOp();
			String [] S = null;//should be initialized
			String type=new String(), type1= new String();
			// get left and right child and validate
			// left and right child could be table.column = table.column
			if (node.getLeftChild() instanceof AttrNode && node.getRightChild() instanceof ValueNode){
				// collect attribute
				AttrNode anode = (AttrNode)node.getLeftChild();
				String colname = anode.getAttrName();
				String tablename = anode.getTableName();
				//-------
				ValueNode bnode = (ValueNode)node.getRightChild();
				String value = bnode.getValue();
				type1 = bnode.getValueType();
				if(type1.matches("string"))
					type1="varchar";
				else if(type1.matches("long"))
					type1="int";
				boolean flag = false;
				if(tablename==null ) {
					for (Iterator j = tbl.iterator();j.hasNext();){
						Tbl t1 = (Tbl)j.next();
						S = t1.getColNames().split(":");
						int i;
						for(i=0;i<S.length;i++)
							if(S[i].matches(colname))
							{
								flag = true;
								break;
							}
						if(flag==true)
						{	
							type= t1.getColTypes().split(":")[i];
							break;
						}
					}
				}
				else {
					for (Iterator j = tbl.iterator();j.hasNext();){
						Tbl t1 = (Tbl)j.next();
						if (tablename.equals(t1.getTblName()) && t1.getColNames().contains(colname) ) {
							 //we have to use split number and retrieve corresponding type n check
							int i;
							S = t1.getColNames().split(":");
							for(i=0;i<S.length;i++) {
								if(colname.matches(S[i]))
									break;
							}
							type= t1.getColTypes().split(":")[i];
							flag = true;
							break;
						}
					}
				}
				if(flag==false)
					throw (new Exception("Invalid where clause"));
				// else throw exception
			}//***********
			else if (node.getRightChild() instanceof AttrNode && node.getLeftChild() instanceof ValueNode){
				// collect attribute
				AttrNode anode = (AttrNode)node.getRightChild();
				String colname = anode.getAttrName();
				String tablename = anode.getTableName();
				//-------
				ValueNode bnode = (ValueNode)node.getLeftChild();
				String value = bnode.getValue();
				type1 = bnode.getValueType();
				if(type1.matches("string"))
					type1="varchar";
				else if(type1.matches("long"))
					type1="int";
				boolean flag = false;
				if(tablename==null ) {
					for (Iterator j = tbl.iterator();j.hasNext();){
						Tbl t1 = (Tbl)j.next();
						S = t1.getColNames().split(":");
						int i;
						for(i=0;i<S.length;i++)
							if(S[i].matches(colname))
							{
								flag = true;
								break;
							}
						if(flag==true)
						{	
							type= t1.getColTypes().split(":")[i];
							break;
						}
					}
				}
				else {
					for (Iterator j = tbl.iterator();j.hasNext();){
						Tbl t1 = (Tbl)j.next();
						if (tablename.equals(t1.getTblName()) && t1.getColNames().contains(colname) ) {
							 //we have to use split number and retrieve corresponding type n check
							int i;
							S = t1.getColNames().split(":");
							for(i=0;i<S.length;i++) {
								if(colname.matches(S[i]))
									break;
							}
							type= t1.getColTypes().split(":")[i];
							flag = true;
							break;
						}
					}
				}
				if(flag==false)
					throw (new Exception("Invalid where clause"));
				// else throw exception
			}//**************
			else if (node.getLeftChild() instanceof AttrNode  && node.getRightChild() instanceof AttrNode ){
				AttrNode anode = (AttrNode)node.getLeftChild();
				String colname = anode.getAttrName();
				String tablename = anode.getTableName();
				//-----
				AttrNode bnode = (AttrNode)node.getRightChild();
				String colname1 = bnode.getAttrName();
				String tablename1 = bnode.getTableName();
				//----------
				
				boolean flag = false;
				if(tablename==null ) {
					for (Iterator j = tbl.iterator();j.hasNext();){
						Tbl t1 = (Tbl)j.next();
						S = t1.getColNames().split(":");
						int i;
						for(i=0;i<S.length;i++)
							if(S[i].matches(colname))
							{
								flag = true;
								break;
							}
						if(flag==true)
						{	
							type= t1.getColTypes().split(":")[i];
							break;
						}
					}
				}
				else {
					for (Iterator j = tbl.iterator();j.hasNext();){
						Tbl t1 = (Tbl)j.next();
						if (tablename.equals(t1.getTblName()) && t1.getColNames().contains(colname) ) {
							 //we have to use split number and retrieve corresponding type n check
							int i;
							S = t1.getColNames().split(":");
							for(i=0;i<S.length;i++) {
								if(colname.matches(S[i]))
									break;
							}
							
							type= t1.getColTypes().split(":")[i];
							
							flag = true;
							break;
						}
					}
				}
				//-------------
				if(flag==false)
					throw (new Exception("Invalid where clause"));
				//--------
				flag=false; //reinitialization (wasted lot of time :) )
				if(tablename==null ) {
					for (Iterator j = tbl.iterator();j.hasNext();){
						Tbl t1 = (Tbl)j.next();
						S = t1.getColNames().split(":");
						int i;
						for(i=0;i<S.length;i++)
							if(S[i].matches(colname))
							{
								flag = true;
								break;
							}
						if(flag==true)
						{	
							type= t1.getColTypes().split(":")[i];
							break;
						}
					}
				}
				else {
					for (Iterator j = tbl.iterator();j.hasNext();){
						Tbl t1 = (Tbl)j.next();
						if (tablename1.equals(t1.getTblName()) && t1.getColNames().contains(colname1) ) {
							 //we have to use split number and retrieve corresponding type n check
							S = t1.getColNames().split(":");
							int i;
							for(i=0;i<S.length;i++) {
								if(colname1.matches(S[i]))
									break;
							}
							type1= t1.getColTypes().split(":")[i];
							flag = true;
							break;
						}
					}
				}
				if(flag==false)
					throw (new Exception("Invalid where clause"));
			}
			if( (!(type.matches(type1)))) {
				throw (new Exception("Invalid where clause:type miss match"));
			}
					
				
		} else {
			// if not a valid left and right child, we throw exception
			throw (new Exception("Invalid where clause"));
		}
		// recrursively iterate the tree until you visit the opnode
	
			validate(node.getLeftChild());
			//node.display();
			validate(node.getRightChild());
	}

}